#This is free and unencumbered software released into the public domain.

#Anyone is free to copy, modify, publish, use, compile, sell, or
#distribute this software, either in source code form or as a compiled
#binary, for any purpose, commercial or non-commercial, and by any
#means.

#In jurisdictions that recognize copyright laws, the author or authors
#of this software dedicate any and all copyright interest in the
#software to the public domain. We make this dedication for the benefit
#of the public at large and to the detriment of our heirs and
#successors. We intend this dedication to be an overt act of
#relinquishment in perpetuity of all present and future rights to this
#software under copyright law.

#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
#OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
#ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
#OTHER DEALINGS IN THE SOFTWARE.

#For more information, please refer to <https://unlicense.org>


# ---


# PROGRAM START

# Setup

# Import random (This should be at the top of the program)
import random

# Declare variables
question = 0;
questionNo = 0;


# This randomizes the questions so that they appear in a different order every time the program is run.
questionList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
random.shuffle(questionList);


# Answer lists
question0 = ["If you lack wisdom, ask God.", "Scriptures can make you wise unto salvation.", "Believe in God and that He has all wisdom."];
random.shuffle(question0);
que0ans = "If you lack wisdom, ask God."
		# correct answer: "If you lack wisdom, ask God."

question1 = ["The Father and Son have bodies of flesh and bone.", "All are alike unto God.", "God is the Father of our spirits."];
random.shuffle(question1);
que1ans = "The Father and Son have bodies of flesh and bone."
		# correct answer: "The Father and Son have bodies of flesh and bone."

question2 = ["God's work and glory is to bring to pass the immortality and eternal life of man.", "Your body is a temple.", "Adam fell that men might be."];
random.shuffle(question2);
que2ans = "God's work and glory is to bring to pass the immortality and eternal life of man."
		# correct answer: "God's work and glory is to bring to pass the immortality and eternal life of man."

question3 = ["The Savior suffered for our sins so we could repent.", "Faith without works is dead.", "If we repent, our sins will be as white as snow."];
random.shuffle(question3);
que3ans = "The Savior suffered for our sins so we could repent."
		# correct answer: "The Savior suffered for our sins so we could repent."

question4 = ["This church is the only true and living church on the Earth today.", "Apostasy was foretold.", "God's kindgod shall stand forever."];
random.shuffle(question4);
que4ans = "This church is the only true and living church on the Earth today."
		# correct answer: "This church is the only true and living church on the Earth today."

question5 = ["The Lord's church is founded on apostles and prophets.", "The voice of the Lord and His servants is the same.", "The Lord's watchmen give warnings from Him."];
random.shuffle(question5);
que5ans = "The Lord's church is founded on apostles and prophets."
		# correct answer: "The Lord's church is founded on apostles and prophets."

question6 = ["Priesthood power depends on one's righteousness.", "The Lord's representatives must be called by one who has authority.", "Jesus Christ promised to build His Church and confer the keys of the kingdom."];
random.shuffle(question6);
que6ans = "Priesthood power depends on one's righteousness."
		# correct answer: "Priesthood power depends on one's righteousness."

question7 = ["We must be born of water and of the Spirit to enter the kingdom of God.", "To stand worthy in the Lord's presence, we must have clean hands and a pure heart.", "The Lord is bound when we do what He says."];
random.shuffle(question7);
que7ans = "We must be born of water and of the Spirit to enter the kingdom of God."
		# correct answer: "We must be born of water and of the Spirit to enter the kingdom of God."

question8 = ["Only together can a man and a woman fulfill the Lord's plan.", "Go no more after the lust of your eyes.", "Multiply and replenish the Earth."];
random.shuffle(question8);
que8ans = "Only together can a man and a woman fulfill the Lord's plan."
		# correct answer: "Only together can a man and a woman fulfill the Lord's plan."

question9 = ["If we love the Lord, we should keep His commandments.", "By serving others, we serve God.", "We are required to forgive all people."];
random.shuffle(question9);
que9ans = "If we love the Lord, we should keep His commandments."
		# correct answer: "If we love the Lord, we should keep His commandments."


# This function checks which question is next being asked and then asks it.
def queCheck():
	
	# question 0
		if (question == 0):
			print(" ");
			print("What truth can be found in James 1:5-6?");
			print("a. "+question0[0]);
			print("b. "+question0[1]);
			print("c. "+question0[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question0[0] == que0ans):
					print(" ");
					print("Correct :D");
				if (question0[0] != que0ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question0[1] == que0ans):
						print(" ");
						print("Correct :D");
					if (question0[1] != que0ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question0[2] == que0ans):
							print(" ");
							print("Correct :D");
						if (question0[2] != que0ans):
							print(" ");
							print("Incorrect :(");	
	
	# question 1
		if (question == 1):
			print(" ");
			print("What do we learn from D&C 130:22-23?");
			print("a. "+question1[0]);
			print("b. "+question1[1]);
			print("c. "+question1[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question1[0] == que1ans):
					print(" ");
					print("Correct :D");
				if (question1[0] != que1ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question1[1] == que1ans):
						print(" ");
						print("Correct :D");
					if (question1[1] != que1ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question1[2] == que1ans):
							print(" ");
							print("Correct :D");
						if (question1[2] != que1ans):
							print(" ");
							print("Incorrect :(");	
	
	# question 2
		if (question == 2):
			print(" ");
			print("What knowledge is found in Moses 1:39?");
			print("a. "+question2[0]);
			print("b. "+question2[1]);
			print("c. "+question2[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question2[0] == que2ans):
					print(" ");
					print("Correct :D");
				if (question2[0] != que2ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question2[1] == que2ans):
						print(" ");
						print("Correct :D");
					if (question2[1] != que2ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question2[2] == que2ans):
							print(" ");
							print("Correct :D");
						if (question2[2] != que2ans):
							print(" ");
							print("Incorrect :(");	

	# question 3
		if (question == 3):
			print(" ");
			print("What truth do we learn of in D&C 19:16-19?");
			print("a. "+question3[0]);
			print("b. "+question3[1]);
			print("c. "+question3[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question3[0] == que3ans):
					print(" ");
					print("Correct :D");
				if (question3[0] != que3ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question3[1] == que3ans):
						print(" ");
						print("Correct :D");
					if (question3[1] != que3ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question3[2] == que3ans):
							print(" ");
							print("Correct :D");
						if (question3[2] != que3ans):
							print(" ");
							print("Incorrect :(");	

	# question 4
		if (question == 4):
			print(" ");
			print("What do we learn from D&C 1:30?");
			print("a. "+question4[0]);
			print("b. "+question4[1]);
			print("c. "+question4[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question4[0] == que4ans):
					print(" ");
					print("Correct :D");
				if (question4[0] != que4ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question4[1] == que4ans):
						print(" ");
						print("Correct :D");
					if (question4[1] != que4ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question4[2] == que4ans):
							print(" ");
							print("Correct :D");
						if (question4[2] != que4ans):
							print(" ");
							print("Incorrect :(");

	# question 5
		if (question == 5):
			print(" ");
			print("What truth is taught in Ephesians 2:19-20");
			print("a. "+question5[0]);
			print("b. "+question5[1]);
			print("c. "+question5[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question5[0] == que5ans):
					print(" ");
					print("Correct :D");
				if (question5[0] != que5ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question5[1] == que5ans):
						print(" ");
						print("Correct :D");
					if (question5[1] != que5ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question5[2] == que5ans):
							print(" ");
							print("Correct :D");
						if (question5[2] != que5ans):
							print(" ");
							print("Incorrect :(");

	# question 6
		if (question == 6):
			print(" ");
			print("This doctrine is found in D&C 121:36, 41-42.");
			print("a. "+question6[0]);
			print("b. "+question6[1]);
			print("c. "+question6[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question6[0] == que6ans):
					print(" ");
					print("Correct :D");
				if (question6[0] != que6ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question6[1] == que6ans):
						print(" ");
						print("Correct :D");
					if (question6[1] != que6ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question6[2] == que6ans):
							print(" ");
							print("Correct :D");
						if (question6[2] != que6ans):
							print(" ");
							print("Incorrect :(");

	# question 7
		if (question == 7):
			print(" ");
			print("This truth is contained in John 3:5.");
			print("a. "+question7[0]);
			print("b. "+question7[1]);
			print("c. "+question7[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question7[0] == que7ans):
					print(" ");
					print("Correct :D");
				if (question7[0] != que7ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question7[1] == que7ans):
						print(" ");
						print("Correct :D");
					if (question7[1] != que7ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question7[2] == que7ans):
							print(" ");
							print("Correct :D");
						if (question7[2] != que7ans):
							print(" ");
							print("Incorrect :(");

	# question 8
		if (question == 8):
			print(" ");
			print("In 1 Corinthians 11:11, we learn of this truth.");
			print("a. "+question8[0]);
			print("b. "+question8[1]);
			print("c. "+question8[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question8[0] == que8ans):
					print(" ");
					print("Correct :D");
				if (question8[0] != que8ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question8[1] == que8ans):
						print(" ");
						print("Correct :D");
					if (question8[1] != que8ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question8[2] == que8ans):
							print(" ");
							print("Correct :D");
						if (question8[2] != que8ans):
							print(" ");
							print("Incorrect :(");

	# question 9
		if (question == 9):
			print(" ");
			print("What do we learn from John 14:15?");
			print("a. "+question9[0]);
			print("b. "+question9[1]);
			print("c. "+question9[2]);
			print(" ");
			yourAns = input("Your answer: ");
			
			# if 'a'
			if (yourAns == "a"):
				if (question9[0] == que9ans):
					print(" ");
					print("Correct :D");
				if (question9[0] != que9ans):
					print(" ");
					print("Incorrect :(");
			else:
					
				# if 'b'
				if (yourAns == "b"):
					if (question9[1] == que9ans):
						print(" ");
						print("Correct :D");
					if (question9[1] != que9ans):
						print(" ");
						print("Incorrect :(");
				else:	

					# if 'c'
					if (yourAns == "c"):
						if (question9[2] == que9ans):
							print(" ");
							print("Correct :D");
						if (question9[2] != que9ans):
							print(" ");
							print("Incorrect :(");


	# This function asks a question and then moves on to the next one.
def queExecute():
	queCheck();
	print(" ");
	print(" ");



# Execution
	
# This next section is the very beginning of the quiz.
print("Welcome to this Doctrinal Mastery Quiz. This quiz covers one question from each Doctrinal Mastery topic.");
print("Are you ready to test your knowledge?");
askStart = input("Type 'yes' to start. Type anything else to exit. Press enter when you have finished typing. ");
if (askStart != "yes"):
	print("Goodbye.");
if (askStart == "yes"):
	print(" ");
	print("Here is your first question. To respond, type the letter that corresponds with your answer. Then press enter.");

# Excecute Questions

# Question 0
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 1
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 2
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 3
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 4
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 5
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 6
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 7
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 8
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

# Question 9
question = (questionList[questionNo]);
queExecute();
questionNo = questionNo + 1;

print("That's the end. Thanks for playing!");
print(" ");
print("- Ajojen");

# PROGRAM END